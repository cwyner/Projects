package com.example.myapplication;

public interface GameStart {

    void playButtonClick();

    void exitButtonClick();
}
