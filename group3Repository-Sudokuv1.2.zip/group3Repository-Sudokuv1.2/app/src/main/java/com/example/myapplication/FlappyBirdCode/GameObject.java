package com.example.myapplication.FlappyBirdCode;

public class GameObject {
    private int gameState;

    public int getGameState() {
        return gameState;
    }
    public void setGameState(int gameState) {
        this.gameState = gameState;
    }
}
